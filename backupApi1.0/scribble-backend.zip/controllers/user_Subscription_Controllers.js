const { UserSubscription } = require('../models/user_Subscription_Model');
const express = require('express');
const router = express.Router();
const { Users } = require('../models/user_Auth_Model')



//user subcription



router.post('/createsubscription', async (req, res) => {

    let createsubscription = new UserSubscription({
        basic: req.body.basic,
        delux: req.body.delux,
        unlimited: req.body.unlimited,
        userid: req.body.userid
    })
    createsubscription = await createsubscription.save();


    if (!createsubscription) {
        return res.status(200).json({
            success: false,
            message: "user not subscribe"
        })
    }
    console.log(createsubscription._id.toHexString())
    const userupdatesubscription = await Users.findByIdAndUpdate(
        req.body.userid,
        {
            $push: {
                userSubscription: createsubscription._id.toHexString()
            }
        },
        { new: true }
    )

    if (!userupdatesubscription) {
        return res.status(200).json({
            success: false,
            message: "user update subscription not create"
        })
    }





    res.status(200).json({
        success: true,
        message: "user update subscribe create",
        data: userupdatesubscription
    })
})

//get 


router.get('/getsubscription', async (req, res) => {

    let createsubscription = await UserSubscription.find();


    if (!createsubscription) {
        return res.status(200).json({
            success: false,
            message: "subscribe not found"
        })
    }

    res.status(200).json({
        success: true,
        message: "subscribe found",
        data: createsubscription
    })
})





module.exports = router;