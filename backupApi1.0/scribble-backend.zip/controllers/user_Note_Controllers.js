const { UserNote } = require('../models/user_Note_Model');
const { Users } = require('../models/user_Auth_Model');
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');




//create note


router.post('/createnote', async (req, res) => {
    let createnote = new UserNote({

        note_title: req.body.note_title,
        note_description: req.body.note_description,
        userid: req.body.userid

    })

    createnote = await createnote.save();

    if (!createnote) {

        return res.status(200).json({
            success: false,
            message: "note not create"
        })
    }

    console.log(createnote._id.toHexString())
    const userupdatenote = await Users.findByIdAndUpdate(
        req.body.userid,
        {
            $push: {
                userNote: createnote._id.toHexString()
            }
        },
        { new: true }
    )

    if (!userupdatenote) {
        return res.status(200).json({
            success: false,
            message: "user update note not create"
        })
    }
    res.status(200).json({
        success: true,
        message: "note creted",
        data: userupdatenote
    })
})


//get note

router.get('/getnote', async (req, res) => {
    let getnote = await UserNote.find();



    if (!getnote) {

        return res.status(200).json({
            success: false,
            message: "note not found"
        })
    }
    res.status(200).json({
        success: true,
        message: "note found",
        data: getnote
    })
})

// get note by id

router.get('/getnotebyid/:id', async (req, res) => {
    let getnotebyid = await UserNote.find({ userid: mongoose.Types.ObjectId(req.params.id) })




    if (!getnotebyid) {

        return res.status(200).json({
            success: false,
            message: "note not found"
        })
    }
    res.status(200).json({
        success: true,
        message: "note found",
        data: getnotebyid
    })
});

// update note by id


router.put('/updatenotebyid/:id', async (req, res) => {
    let updatenotebyid = await UserNote.findByIdAndUpdate(req.params.id, {

        note_title: req.body.note_title,
        note_description: req.body.note_description
    });



    if (!updatenotebyid) {

        return res.status(200).json({
            success: false,
            message: "note not update"
        })
    }
    res.status(200).json({
        success: true,
        message: "note update",
        data: updatenotebyid
    })
});


// delete note by id



router.delete('/deletenotebyid/:id', async (req, res) => {
    let deletenotebyid = await UserNote.findByIdAndDelete(req.params.id)


    if (!deletenotebyid) {

        return res.status(200).json({
            success: false,
            message: "note not delete"
        })
    }
    res.status(200).json({
        success: true,
        message: "note delete",
        data: deletenotebyid
    })
});



//count note


router.get('/notecount', async (req, res) => {


    let notecount = await UserNote.estimatedDocumentCount();

    if (!notecount) {
        return res.status(200).json({
            success: false,
            message: "user profile not count"
        })
    }
    res.status(200).json({
        success: true,
        message: "user profile count",
        notecount: notecount
    })


})

module.exports = router;