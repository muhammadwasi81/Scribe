const { UserChat } = require('../models/user_Chat_Model');
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const { Users } = require('../models/user_Auth_Model')


//create chat 


router.post('/createchat', async (req, res) => {


    let createchat = new UserChat({
        sentmsg: req.body.sentmsg,
        recievemsg: req.body.recievemsg,
        userid: req.body.userid
    })

    createchat = await createchat.save();

    if (!createchat) {

        return res.status(200).json({
            success: false,
            message: "chat is not create"
        })
    }
    let postchatbyuser = await Users.findByIdAndUpdate(
        req.body.userid, {
        $push: {
            userChat: createchat._id.toHexString()
        }


    })
    console.log(createchat._id.toHexString())
    console.log(postchatbyuser)
    if (!postchatbyuser) {
        return res.status(200).json({
            success: false,
            message: "chat update create",
        })

    }

    res.status(200).json({
        success: true,
        message: "chat update is create",
        data: postchatbyuser
    })

});

router.get('/getchat', async (req, res) => {


    let getchat = await UserChat.find();

    if (!getchat) {
        return res.status(200).json({
            success: false,
            message: "user chat not found"
        })
    }

    res.status(200).json({
        success: true,
        message: "user chat found",
        data: getchat
    })


})

//get chat by user

router.get('/getchatbyuser/:id', async (req, res) => {


    let getchatbyuser = await UserChat.find({ userid: mongoose.Types.ObjectId(req.params.id) }).populate(['userid']);

    if (!getchatbyuser) {
        return res.status(200).json({ success: false, message: "something went wrong" })
    }
    res.status(200).json({ success: true, data: getchatbyuser })

})



module.exports = router;