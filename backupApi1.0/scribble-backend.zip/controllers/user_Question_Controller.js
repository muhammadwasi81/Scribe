const { UserQuestion } = require('../models/user_Question_Model');
const express = require('express');
const router = express.Router();
const { Users } = require('../models/user_Auth_Model')


//post question


router.post('/createquestion', async (req, res) => {


    let postquestion = new UserQuestion({
        userquestion: req.body.userquestion,
        userid: req.body.userid,
        isAnonymouse: req.body.isAnonymouse

    })

    postquestion = await postquestion.save();

    if (!postquestion) {
        return res.status(200).json({
            success: false,
            message: "user question not post"
        })
    }

    res.status(200).json({
        success: true,
        message: "user question post",
        data: postquestion
    })

})


router.post('/answerquestion/:id', async (req, res) => {


    let postanswer = await UserQuestion.findByIdAndUpdate(
        req.params.id, {
        $push: {
            answers: {
                answer: req.body.answer,
                userid: req.body.userid
            }

        }
    }, { new: true }).populate(['userid', {
        path: 'answers',
        populate: {
            path: 'userid',
            model: 'users'
        }

    }],


    )

    if (!postanswer) {
        return res.status(200).json({
            success: false,
            message: "update comment not post",
        })

    }
    res.status(200).json({
        success: true,
        message: 'update comment on post',
        data: postanswer
    })

})

//get question


router.get('/getquestion', async (req, res) => {

    let getquestion = await UserQuestion.find().populate(['userid', {
        path: 'answers',
        populate: {
            path: 'userid',
            model: 'users'
        }

    }]);

    if (!getquestion) {
        return res.status(200).json({
            success: false,
            message: "user question not get"
        })
    }
    res.status(200).json({
        success: true,
        message: "user question get",
        data: getquestion
    })


})

//get question by id



router.get('/getquestionbyid/:id', async (req, res) => {

    let getquestionbyid = await UserQuestion.findById(req.params.id);

    if (!getquestionbyid) {
        return res.status(200).json({
            success: false,
            message: "user question not get"
        })
    }
    res.status(200).json({
        success: true,
        message: "user question get",
        data: getquestionbyid
    })

})
//update question

router.put('/updatequestionbyid/:id', async (req, res) => {

    let updatequestionbyid = await UserQuestion.findByIdAndUpdate(req.params.id, {
        userquestion: req.body.userquestion
    }, { new: true });

    if (!updatequestionbyid) {
        return res.status(200).json({
            success: false,
            message: "user question not update"
        })
    }
    res.status(200).json({
        success: true,
        message: "user question update",
        data: updatequestionbyid
    })

})

//delete question by id

router.delete('/deletequestionbyid/:id', async (req, res) => {

    let deletequestionbyid = await UserQuestion.findByIdAndDelete(req.params.id);

    if (!deletequestionbyid) {
        return res.status(200).json({
            success: false,
            message: "user question not delete"
        })
    }
    res.status(200).json({
        success: true,
        message: "user question delete",
        data: deletequestionbyid
    })

})







module.exports = router;