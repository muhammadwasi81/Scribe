const { UserFeed } = require('../models/user_Feed_Model');
const express = require('express');
const router = express.Router();
const { Users } = require('../models/user_Auth_Model')


//create user feed


router.post('/createuserfeed', async (req, res) => {


    let createuserfeed = new UserFeed({


        userpost: req.body.userpost,
        userid: req.body.userid

    })

    createuserfeed = await createuserfeed.save();



    if (!createuserfeed) {

        return res.status(200).json({


            success: false,
            message: "user feed not create"
        })
    }
    console.log(createuserfeed._id.toHexString())
    const userupdatefeed = await Users.findByIdAndUpdate(
        req.body.userid,
        {
            $push: {
                userFeed: createuserfeed._id.toHexString()
            }
        },
        { new: true }
    )

    if (!userupdatefeed) {
        return res.status(200).json({
            success: false,
            message: "user update feed not create"
        })
    }
    res.status(200).json({

        success: true,
        message: "user update feed create",
        data: userupdatefeed
    })

})

//get userfeed


router.get('/getuserfeed', async (req, res) => {


    let getuserfeed = await UserFeed.find();

    if (!getuserfeed) {
        return res.status(200).json({
            success: false,
            message: "user feed not create"
        })
    }

    res.status(200).json({
        success: true,
        message: "user feed create",
        data: getuserfeed
    })
});



module.exports = router;