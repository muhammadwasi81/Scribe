const mongoose = require('mongoose');

const usersubscriptionschema = new mongoose.Schema({

    basic: {
        type: String,
        required: true
    },
    delux: {
        type: String,
        required: true
    },
    unlimited: {
        type: String,
        required: true
    },

    userid: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'users'
    },
    createdOn: {
        type: Date,
        default: Date.now
    }






})

usersubscriptionschema.virtual('id').get(function () {
    return this._id.toHexString();
});

usersubscriptionschema.set('toJSON', {
    virtuals: true,
});
 
exports.UserSubscription = mongoose.model('usersubscription', usersubscriptionschema);
exports.usersubscriptionschema = usersubscriptionschema;