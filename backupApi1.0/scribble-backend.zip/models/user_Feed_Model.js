const mongoose = require('mongoose');
const userfeedschema = new mongoose.Schema({


   userpost: {

      type: String,
      required: true

   },

   userid: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'users'
   },
   createdOn: {
      type: Date,
      default: Date.now
   }



})
userfeedschema.virtual('id').get(function () {
   return this._id.toHexString();
});

userfeedschema.set('toJSON', {
   virtuals: true,
});
exports.UserFeed = mongoose.model('userfeed', userfeedschema);
exports.userfeedschema = userfeedschema;