const mongoose = require('mongoose');
const usernotificationschema = new mongoose.Schema({

    title: {
        type: String,
    },

    subtitle: {
        type: String,
    },
    notificationtype: {
        type: Number,
        //0) Follow 1)UnFollow  2)comment tag
    },
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    userdata: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    postid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'userpost'
    },
    notificationCreatedOn: {
        type: Date,
        default: Date.now
    },
})

usernotificationschema.virtual('id').get(function () {
    return this._id.toHexString();
});

usernotificationschema.set('toJSON', {
    virtuals: true,
});
exports.UserNotification = mongoose.model('usernotification', usernotificationschema);
exports.usernotificationschema = usernotificationschema;