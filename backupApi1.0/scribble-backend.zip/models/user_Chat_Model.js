const mongoose = require('mongoose');

const userchatschema = new mongoose.Schema({

    sentmsg: {
        type: String,
    },
    recievemsg: {
        type: String,
    },

    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    createdOn: {
        type: Date,
        default: Date.now
    }






})
userchatschema.virtual('id').get(function () {
    return this._id.toHexString();
});

userchatschema.set('toJSON', {
    virtuals: true,
});


exports.UserChat = mongoose.model('userchat', userchatschema);
exports.userchatschema = userchatschema;