const mongoose = require('mongoose');
const userquestionschema = new mongoose.Schema({

    userquestion: {
        type: String,
        required: true
    },
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'users'
    },

    createdOn: {
        type: Date,
        default: Date.now
    },

    isAnonymouse: {
        type: Boolean,
        default: false
    },

    answers: [
        {
            answer: {
                type: String,
                required: true
            },
            userid: {
                type: mongoose.Schema.Types.ObjectId,
                required: true,
                ref: 'users'
            },

            createdOn: {
                type: Date,
                default: Date.now
            },

        }
    ],
})

userquestionschema.virtual('id').get(function () {
    return this._id.toHexString();
});

userquestionschema.set('toJSON', {
    virtuals: true,
});
exports.UserQuestion = mongoose.model('userquestion', userquestionschema);
exports.userquestionschema = userquestionschema;