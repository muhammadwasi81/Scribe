const mongoose = require('mongoose');

const userchatroomschema = new mongoose.Schema({

    messages: [{

        message: {
            type: String,
        },
        isAdmin: {
            type: Boolean,
            default: true
        },
        createdOn: {
            type: Date,
            default: Date.now
        }
    }],

    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    createdOn: {
        type: Date,
        default: Date.now
    }
})
userchatroomschema.virtual('id').get(function () {
    return this._id.toHexString();
});

userchatroomschema.set('toJSON', {
    virtuals: true,
});


exports.UserChatRoom = mongoose.model('chatrooms', userchatroomschema);
exports.userchatroomschema = userchatroomschema;