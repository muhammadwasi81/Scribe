const mongoose = require('mongoose');
const usernoteschema = new mongoose.Schema({

    note_title: {
        type: String,
        required: true
    },
    note_description: {
        type: String,
        required: true
    },

    userid: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'users'


    },
    createdOn: {
        type: Date,
        default: Date.now
    }

});
usernoteschema.virtual('id').get(function () {
    return this._id.toHexString();
});

usernoteschema.set('toJSON', {
    virtuals: true,
});

exports.UserNote = mongoose.model('usernote', usernoteschema);
exports.usernoteschema = usernoteschema;