const mongoose = require('mongoose');

const userreviewschema = new mongoose.Schema({

    userreview: {
        type: String,
        required: true
    },
    userrating: {
        type: Number,
        required: true
    },

    userid: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'users'
    },
    createdOn: {
        type: Date,
        default: Date.now
    }






})

userreviewschema.virtual('id').get(function () {
    return this._id.toHexString();
});

userreviewschema.set('toJSON', {
    virtuals: true,
});
exports.UserReview = mongoose.model('userreview', userreviewschema);
exports.userreviewschema = userreviewschema;