const express = require("express");
const app = express();
const http = require("http");
const https = require("https");

const mongoose = require("mongoose");
const bodyparser = require("body-parser");
require("dotenv/config");
const api = process.env.API_URL;
const environment = process.env.ENVIRONMENT;
const server =
  environment === "production"
    ? https.createServer(
        // Provide the private and public key to the server by reading each
        // file's content with the readFileSync() method.
        {
          key: fs.readFileSync(
            "/home/api1jumppace/ssl/keys/9a100_4411d_f5a33bf0b8cef9e23f7a6222a94e52ea.key"
          ),
          cert: fs.readFileSync(
            "/home/api1jumppace/ssl/certs/api1_jumppace_com_9a100_4411d_1678319999_422d9cb7a190cbdf43a31ac47845c0c8.crt"
          ),
          ca: [fs.readFileSync("/home/api1jumppace/ssl/certs/ca_bundle.crt")]
        },app
        
      )
    : http.createServer(app);


const { UserChatSingle } = require("./models/user_Chat1o1_Model");

var cors = require("cors");
app.use(cors());
//route
const auth = require("./controllers/user_Auth_Controllers");
const userreview = require("./controllers/user_Review_Controllers");
const usersubscription = require("./controllers/user_Subscription_Controllers");
const userpost = require("./controllers/user_Post_Controllers");
const usernote = require("./controllers/user_Note_Controllers");
const userlibrary = require("./controllers/user_Libarary_Controllers");
const userfeed = require("./controllers/user_Feed_Controllers");
const userchat = require("./controllers/user_Chat_Controllers");
const userquestion = require("./controllers/user_Question_Controller");
const usernotification = require("./controllers/user_Notification_Controllers");
const usercomment = require("./controllers/user_comment_controllers");

//middleware
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
app.use(`${api}`, auth);
app.use(`${api}`, userreview);
app.use(`${api}`, usersubscription);
app.use(`${api}`, userpost);
app.use(`${api}`, usernote);
app.use(`${api}`, userlibrary);
app.use(`${api}`, userfeed);
app.use(`${api}`, userchat);
app.use(`${api}`, userquestion);
app.use(`${api}`, usernotification);
app.use(`${api}`, usercomment);

app.use("/public/uploads", express.static(__dirname + "/public/uploads"));

mongoose
  .connect(process.env.COLLECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    dbName: "scribble_production",
  })
  .then(() => {
    console.log("database is connected");
  })
  .catch(() => {
    console.log("database is not connected");
  });

function uniq(a, param) {
  return a.filter(function (item, pos, array) {
    return (
      array
        .map(function (mapItem) {
          return mapItem[param];
        })
        .indexOf(item[param]) === pos
    );
  });
}

app.get("/", (req, res) => {
  res.send(`${api}/oo`);
});

const PORT = process.env.PORT || 3060;

// https
//     .createServer(
//         // Provide the private and public key to the server by reading each
//         // file's content with the readFileSync() method.
//         {
//             key: fs.readFileSync("key.pem"),
//             cert: fs.readFileSync("cert.pem"),
//         },
//         app
//     )
//     .listen(PORT, () => {
//         console.log(`App listening on port ${PORT}!`)
//     });
// app.listen(PORT, () => { console.log(`App listening on port ${PORT}!`); });

const  io   = require("socket.io")(http);
// const io =  socketIO(server);
io.on('connection', (socket) => {
  console.log("a user connected");

  socket.on("getchatlistofuser", async (msg) => {
    
    const getroomchat = await UserChatSingle.find({
      $or: [
        { userid2: { $in: mongoose.Types.ObjectId(msg.userid2) } },
        { userid1: { $in: mongoose.Types.ObjectId(msg.userid1) } },
      ],

      // $or: [
      //     { 'userid2': { $in: msg.userid1 } },
      //     { 'userid1': { $in: msg.userid1 } },
      // ]
    }).populate(["userid1", "userid2"]);
    console.log(getroomchat);
    let result = getroomchat.filter(
      (person, index) =>
        index ===
        getroomchat.findIndex(
          (other) => person.userid2._id === other.userid2._id
        )
    );

    console.log(result);

    io.emit("chatlist", result);

    // var arrFiltered = uniq(getroomchat.reverse(), 'userid2._id');
    // arrFiltered = uniq(arrFiltered, 'userid1._id');

    // [
    //     {
    //         'userid1' : 12,
    //         'userid2': 11
    //     },
    //     {
    //         'userid1' : 11,
    //         'userid2': 12
    //     }
    // ]
    // const unique = [...new Map(getroomchat.map(item => [item['userid2'], item])).values()]
    // let unique = [...new Map(getroomchat.map(item => [item['userid1'], item])).values()]
    // unique = [...new Map(unique.map(item => [item['userid2'], item])).values()]
    // var uniqueArray = removeDuplicates(getroomchat, "userid2");
    // uniqueArray = removeDuplicates(uniqueArray, "userid1");

    // console.log(Object.values(getroomchat.reduce((acc, cur) => Object.assign(acc, { [cur.userid2._id]: cur }), {})))

    // console.log(uniqueArray)

    // const unique = [...new Map(getroomchat.map(item => [item['userid2'], item])).values()]

    // console.log(getroomchat)
  });
  
  socket.on("getuserchat", async (msg) => {
    console.log(msg);
    const getroomchat = await UserChatSingle.find({
      $or: [
        {
          userid1: { $in: mongoose.Types.ObjectId(msg.userid1) },
          userid2: { $in: mongoose.Types.ObjectId(msg.userid2) },
        },
        {
          userid2: { $in: mongoose.Types.ObjectId(msg.userid1) },
          userid1: { $in: mongoose.Types.ObjectId(msg.userid2) },
        },

        // etc. add your other fields as well here
      ],
    });
    // console.log(getroomchat)
    io.emit("messagerecieved", getroomchat);
  });

  socket.on("sendMessage", async (msg) => {
    const sendMessagetoRoom = UserChatSingle({
      msg: msg.msg,
      userid1: msg.userid1,
      userid2: msg.userid2,
    });
    const send = await sendMessagetoRoom.save();

    const userid2 = await Users.findOne({_id:msg.userid2},{userNotificationToken:1})
    const userid1 = await Users.findOne({_id:msg.userid1})

  
  
  await push_notifications({
    user_device_token:userid2.userNotificationToken,
    title:"New message arrived",      
    body:`${userid1.userFullName} is send you message`,
  })
  
    const getroomchat = await UserChatSingle.find({
      $or: [
        {
          userid1: { $in: mongoose.Types.ObjectId(msg.userid1) },
          userid2: { $in: mongoose.Types.ObjectId(msg.userid2) },
        },
        {
          userid2: { $in: mongoose.Types.ObjectId(msg.userid1) },
          userid1: { $in: mongoose.Types.ObjectId(msg.userid2) },
        },

        // etc. add your other fields as well here
      ],
    });
    // console.log(getroomchat)
    io.emit("messagerecieved", getroomchat);
  });

  socket.on('msg_from_client', function(from,msg){
		console.log('Message is '+from, msg);
	})
});

server.listen(PORT, () => {
  console.log(`App listening on port ${PORT}!`);
});


setInterval(function() {
	io.emit('msg_to_client','client','test msg');	
},1000)